import { useEffect } from "react";

export default function KakaoMap() {
  useEffect(() => {
    // 이미 로드됐다면 중복 로드 방지
    if (window.kakao && window.kakao.maps) return;

    // 스크립트 태그 동적으로 생성
    const script = document.createElement("script");
    script.src = `https://dapi.kakao.com/v2/maps/sdk.js?appkey=${import.meta.env.VITE_KAKAO_MAPS_API_KEY}&autoload=false&libraries=services`;
    script.async = true;

    // 스크립트가 로드된 후 kakao.maps.load 호출
    script.onload = () => {
      window.kakao.maps.load(() => {
        const container = document.getElementById("map");
        const options = {
          center: new window.kakao.maps.LatLng(37.5665, 126.9780), // 서울시청
          level: 3,
        };
        new window.kakao.maps.Map(container, options);
      });
    };

    document.head.appendChild(script);

    // 컴포넌트 unmount 시 script 제거
    return () => {
      document.head.removeChild(script);
    };
  }, []);

  // 지도 그릴 div
  return (
    <div id="map" style={{ width: "100%", height: "400px" }} />
  );
}

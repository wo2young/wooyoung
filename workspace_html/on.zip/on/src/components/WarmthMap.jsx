import React, { useState, useEffect, useRef } from "react";
import { Map, MapMarker } from "react-kakao-maps-sdk";
import Header from "../components/Header";

// 샘플 데이터 fetch 함수 (실제라면 API로 대체)
const fetchMatchingList = async () => [
  {
    id: 1,
    address: "서울특별시 중구 세종대로 110",
    lat: 37.5665,
    lng: 126.9780,
    title: "서울시청 봉사 매칭",
    content: "이곳에서 봉사가 진행중입니다!",
  },
  {
    id: 2,
    address: "서울특별시 종로구 북촌로 30",
    lat: 37.57,
    lng: 126.983,
    title: "북촌 봉사 매칭",
    content: "북촌에서 따뜻한 봉사가 진행 중!",
  },
];

const initialCenter = { lat: 36.80736, lng: 127.1471 };

function KakaoMap() {
  const [matchings, setMatchings] = useState([]);
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState("");
  const [searchMarker, setSearchMarker] = useState(null);
  const [center, setCenter] = useState(initialCenter);
  const mapRef = useRef();

  useEffect(() => {
    fetchMatchingList().then(setMatchings);
  }, []);

  // 카카오 주소 검색
  const handleSearch = () => {
    if (!window.kakao || !window.kakao.maps || !window.kakao.maps.services) {
      alert("지도가 아직 로드되지 않았습니다.");
      return;
    }
    const geocoder = new window.kakao.maps.services.Geocoder();
    geocoder.addressSearch(search, function (result, status) {
      if (status === window.kakao.maps.services.Status.OK) {
        const { y, x } = result[0];
        const latLng = { lat: parseFloat(y), lng: parseFloat(x) };
        setCenter(latLng);
        setSearchMarker(latLng);
        // 지도가 있으면 해당 위치로 이동
        if (mapRef.current) mapRef.current.setCenter(new window.kakao.maps.LatLng(latLng.lat, latLng.lng));
      } else {
        alert("주소를 찾을 수 없습니다.");
      }
    });
  };

  const handleMarkerClick = (point) => {
    setSelected(point);
    setCenter({ lat: point.lat, lng: point.lng });
    if (mapRef.current) mapRef.current.setCenter(new window.kakao.maps.LatLng(point.lat, point.lng));
  };

  return (
    <>
      <Header />
      <div style={{ marginTop: "20px", width: "70vw", margin: "20px auto", position: "relative" }}>
        {/* 검색창 */}
        <div
          style={{
            position: "absolute",
            zIndex: 999,
            top: 20,
            left: "50%",
            transform: "translateX(-50%)",
            display: "flex",
            alignItems: "center",
            background: "#fff",
            borderRadius: 24,
            boxShadow: "0 2px 10px rgba(66,133,244,0.11)",
            padding: 4,
            height: 56,
            minWidth: 320,
          }}
        >
          <input
            type="text"
            value={search}
            placeholder="주소 검색"
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            style={{
              border: "none",
              outline: "none",
              background: "transparent",
              fontSize: 20,
              padding: "0 18px",
              height: 48,
              lineHeight: "48px",
              borderRadius: 18,
              boxSizing: "border-box",
              color: "#222",
              flex: 1,
            }}
          />
          <button
            onClick={handleSearch}
            style={{
              border: "none",
              borderRadius: 24,
              background: "#4285F4",
              color: "#fff",
              fontWeight: 700,
              fontSize: 22,
              height: 48,
              minWidth: 110,
              padding: 0,
              marginLeft: 12,
              cursor: "pointer",
              boxShadow: "0 2px 6px rgba(66,133,244,0.13)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            검색
          </button>
        </div>

        {/* 지도 */}
        <Map
          center={center}
          style={{ width: "100%", height: "400px" }}
          level={5}
          isPanto={true}
          ref={mapRef}
        >
          {matchings.map((point) => (
            <MapMarker
              key={point.id}
              position={{ lat: point.lat, lng: point.lng }}
              onClick={() => handleMarkerClick(point)}
              title={point.title}
            />
          ))}
          {searchMarker && (
            <MapMarker
              position={searchMarker}
              image={{
                src: "https://t1.daumcdn.net/localimg/localimages/07/mapapidoc/markerStar.png",
                size: { width: 24, height: 35 },
              }}
              title="검색 위치"
              onClick={() => setCenter(searchMarker)}
            />
          )}
        </Map>

        {/* 마커 정보 창 */}
        {selected && (
          <div
            style={{
              position: "absolute",
              background: "#fff",
              padding: "10px",
              borderRadius: "10px",
              bottom: "50px",
              left: "50%",
              zIndex: 100,
              boxShadow: "0 2px 6px rgba(0,0,0,0.3)",
              width: "220px",
              transform: "translateX(-50%)",
            }}
          >
            <h4>{selected.title}</h4>
            <p>{selected.content}</p>
            <button onClick={() => setSelected(null)}>닫기</button>
          </div>
        )}
      </div>
    </>
  );
}

export default KakaoMap;

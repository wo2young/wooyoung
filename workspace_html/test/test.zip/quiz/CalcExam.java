package quiz;

import java.util.Scanner;

public class CalcExam {
	
	public static void main(String[] args) {
	
		Calc cal = new Calc();
		Scanner sc = new Scanner(System.in);
		
		
		
		
		
	}

}

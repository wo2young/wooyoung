package src.exam01;

public class HambergerExam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
